const $=s=>document.querySelector(s); let me=null;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(p,m='GET',b){const r=await fetch('/api'+p,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});
  const t=await r.text(); const d=t?JSON.parse(t):{}; if(!r.ok){const e=new Error(d.message||'Request failed');e.status=r.status;throw e} return d}
function toast(m,ok=true){const e=$('#toast');e.className='toast text-bg-'+(ok?'success':'danger');$('#toastMsg').textContent=m;bootstrap.Toast.getOrCreateInstance(e).show()}
const inr=n=>'₹'+Number(n).toLocaleString('en-IN');
async function loadHalls(){
  const p=new URLSearchParams({sort:$('#sort').value}); if($('#q').value)p.set('q',$('#q').value); if($('#minCap').value)p.set('minCapacity',$('#minCap').value);
  const halls=await api('/halls?'+p);
  $('#hallList').innerHTML=halls.length?halls.map(h=>`<div class="col-md-6 col-lg-4"><div class="hall-card"><div class="band"></div><div class="p-4">
   <h3>${esc(h.name)}</h3><p>${esc(h.description)}</p><p class="mb-1">Up to <b>${h.capacity}</b> guests</p><div class="price mb-2">${inr(h.pricePerDay)}<small class="text-muted fs-6"> / day</small></div>
   <div class="mb-3">${(h.facilities||'').split(',').filter(Boolean).map(f=>`<span class="badge badge-f rounded-pill">${esc(f)}</span>`).join('')}</div>
   <button class="btn btn-gold btn-sm" onclick="pick(${h.id})">Book this hall</button></div></div></div>`).join(''):'<p class="text-muted">No halls match your search. Try fewer filters.</p>';
  const cur=$('#hallId').value; $('#hallId').innerHTML=halls.map(h=>`<option value="${h.id}">${esc(h.name)} (${h.capacity} guests, ${inr(h.pricePerDay)})</option>`).join(''); if(cur)$('#hallId').value=cur;
}
function pick(id){$('#hallId').value=id;location.hash='#book'}
['#q','#minCap','#sort'].forEach(s=>$(s).addEventListener('input',loadHalls));
$('#date').min=new Date().toISOString().slice(0,10);
function slot(){return new URLSearchParams({hallId:$('#hallId').value,date:$('#date').value,start:$('#start').value,end:$('#end').value})}
async function check(){
  if(!$('#date').value||!$('#start').value||!$('#end').value){$('#availMsg').innerHTML='<span class="text-danger">Choose a date, start time and end time first.</span>';return false}
  try{const r=await api('/availability?'+slot());$('#availMsg').innerHTML=`<span class="${r.available?'text-success':'text-danger'} fw-semibold">${esc(r.message)}</span>`;return r.available}
  catch(e){$('#availMsg').innerHTML=`<span class="text-danger">${esc(e.message)}</span>`;return false}
}
$('#checkBtn').onclick=check;
$('#bookForm').addEventListener('submit',async e=>{e.preventDefault();
  if(!me){toast('Please log in to request a booking.',false);bootstrap.Modal.getOrCreateInstance($('#authModal')).show();return}
  if(!e.target.checkValidity()){e.target.reportValidity();return}
  try{const b=await api('/bookings','POST',{hallId:+$('#hallId').value,eventType:$('#eventType').value,eventDate:$('#date').value,startTime:$('#start').value,endTime:$('#end').value,
    guests:+$('#guests').value,customerName:$('#cname').value,phone:$('#cphone').value,requirements:$('#req').value});
    toast(`Request received. Booking ID: ${b.bookingCode}. We'll confirm shortly.`);e.target.reset();$('#availMsg').textContent='';loadBookings()}
  catch(err){toast(err.message,false)}});
async function loadBookings(){
  if(!me){$('#bookings').classList.add('d-none');return}
  const list=await api('/bookings'); $('#bookings').classList.remove('d-none'); $('#bkTitle').textContent=me.role==='ADMIN'?'All bookings':'My bookings';
  $('#bkEmpty').classList.toggle('d-none',list.length>0);
  const adm=me.role==='ADMIN', act=(id,s,l,c)=>`<button class="btn btn-sm btn-outline-${c} me-1" onclick="setStatus(${id},'${s}')">${l}</button>`;
  $('#bkBody').innerHTML=list.map(b=>`<tr><td>${esc(b.bookingCode)}</td><td>${esc(b.hall)}<br><small class="text-muted">${esc(b.customerName)} · ${esc(b.eventType)}</small></td>
   <td>${esc(b.eventDate)}<br><small>${esc(b.startTime).slice(0,5)}–${esc(b.endTime).slice(0,5)}</small></td><td>${inr(b.amount)}</td><td><span class="badge text-bg-secondary">${esc(b.status)}</span></td><td>${esc(b.paymentStatus)}</td>
   <td class="text-nowrap">${adm&&b.status==='PENDING'?act(b.id,'CONFIRMED','Confirm','success')+act(b.id,'REJECTED','Reject','danger'):''}${adm&&b.status==='CONFIRMED'?act(b.id,'COMPLETED','Complete','primary'):''}
   ${['PENDING','CONFIRMED'].includes(b.status)?`<button class="btn btn-sm btn-outline-secondary" onclick="cancelBk(${b.id})">Cancel</button>`:''}</td></tr>`).join('');
}
async function setStatus(id,s){try{await api(`/bookings/${id}/status?status=${s}`,'PUT');toast('Booking updated.');loadBookings()}catch(e){toast(e.message,false)}}
async function cancelBk(id){if(!confirm('Cancel this booking?'))return;try{await api('/bookings/'+id,'DELETE');toast('Booking cancelled.');loadBookings()}catch(e){toast(e.message,false)}}
function setUser(u){me=u;$('#navLogin').classList.toggle('d-none',!!u);$('#navUser').classList.toggle('d-none',!u);$('#navBookings').classList.toggle('d-none',!u);if(u){$('#who').textContent=u.fullName+(u.role==='ADMIN'?' (admin)':'');if(!$('#cname').value)$('#cname').value=u.fullName}loadBookings()}
$('#tLogin').addEventListener('submit',async e=>{e.preventDefault();try{setUser(await api('/auth/login','POST',{email:$('#lEmail').value,password:$('#lPass').value}));bootstrap.Modal.getInstance($('#authModal')).hide();toast('Welcome back.')}catch(err){toast(err.message,false)}});
$('#tReg').addEventListener('submit',async e=>{e.preventDefault();
  if($('#rPass').value!==$('#rPass2').value){toast('Passwords do not match.',false);return}
  try{await api('/auth/register','POST',{fullName:$('#rName').value,email:$('#rEmail').value,phone:$('#rPhone').value,password:$('#rPass').value});
    setUser(await api('/auth/login','POST',{email:$('#rEmail').value,password:$('#rPass').value}));bootstrap.Modal.getInstance($('#authModal')).hide();toast('Account created.')}catch(err){toast(err.message,false)}});
$('#logout').onclick=async()=>{await api('/auth/logout','POST');setUser(null);toast('Logged out.')};
loadHalls(); api('/auth/me').then(setUser).catch(()=>setUser(null));

# Grand Celebration Function Hall

Spring Boot + MySQL + Bootstrap booking site. Spring serves the `frontend/` folder, so the site and API share one origin (session cookies work without CORS setup).

## What works
- Register, login, logout (BCrypt hashes, session auth, roles CUSTOMER / ADMIN)
- Hall listing with search (name/facility), minimum capacity and price/capacity sorting; admin hall add/edit/remove APIs
- Availability checker and booking with server-side validation: past dates, end before start, guest capacity, overlap detection
- Overlaps are prevented by locking the hall row inside the booking transaction (MySQL cannot express time-range overlap as a constraint)
- Booking IDs like `FH20260001`; statuses PENDING, CONFIRMED, REJECTED, CANCELLED, COMPLETED
- Customers see and cancel their own bookings; admins see all bookings and confirm, reject or complete them (marking completed sets payment to PAID in this mock setup)
- Global JSON error handling with 400/401/403/404/409/500

## Not built yet
Packages, gallery, reviews, contact form, facilities/events tables, payments table, admin charts and customer management, separate pages, Docker. The entities and layers are set up so each can be added the same way as halls and bookings.

## Requirements
JDK 17+, Maven 3.9+, MySQL 8 running locally.

## Run
1. Start MySQL. The database `function_hall` is created automatically.
2. Set credentials if not root/root: `DB_USER`, `DB_PASSWORD` environment variables (or edit `application.properties`).
3. `cd backend && mvn spring-boot:run` (run from `backend/`, the frontend path is relative)
4. Open http://localhost:8080

## Development accounts (change before deploying)
- Admin: `admin@grandcelebration.com` / `Admin@12345` (override with `ADMIN_PASSWORD`)
- Customer: `customer@example.com` / `Customer@123`
Seeded on first start by `DataSeeder`, along with 3 halls.

## API
| Method | Path | Access |
|---|---|---|
| POST | /api/auth/register, /login, /logout; GET /me | public |
| GET | /api/halls?q=&minCapacity=&sort=capacity\|priceAsc\|priceDesc | public |
| GET | /api/halls/{id}, /api/availability?hallId&date&start&end | public |
| POST/PUT/DELETE | /api/halls[/{id}] | admin |
| GET/POST | /api/bookings | logged in (customers see own, admin sees all) |
| DELETE | /api/bookings/{id} (cancel) | owner or admin |
| PUT | /api/bookings/{id}/status?status=CONFIRMED | admin |

## Troubleshooting
- Blank page or 404 at `/`: start Maven from `backend/` so `../frontend/` resolves.
- MySQL access denied: set `DB_USER` / `DB_PASSWORD`.
- Lombok errors in the IDE: enable annotation processing.

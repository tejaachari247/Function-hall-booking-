package com.functionhall.repository;
import com.functionhall.entity.Hall; import jakarta.persistence.LockModeType; import org.springframework.data.jpa.repository.*; import java.util.*;
public interface HallRepository extends JpaRepository<Hall,Long> {
  List<Hall> findByActiveTrue();
  @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select h from Hall h where h.id = :id") Optional<Hall> lockById(Long id);
}

package com.functionhall.entity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="halls") @Getter @Setter @NoArgsConstructor
public class Hall {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(nullable=false, unique=true) private String name;
  @Column(length=1000) private String description;
  private int capacity;
  @Column(nullable=false) private BigDecimal pricePerDay;
  private String facilities;
  private boolean active = true;
}

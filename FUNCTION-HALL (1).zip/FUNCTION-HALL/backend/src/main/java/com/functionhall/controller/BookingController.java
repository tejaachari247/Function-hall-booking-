package com.functionhall.controller;
import com.functionhall.dto.Dto.BookingReq; import com.functionhall.entity.Booking; import com.functionhall.repository.BookingRepository; import com.functionhall.service.BookingService;
import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.http.HttpStatus; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/bookings") @RequiredArgsConstructor
public class BookingController {
  private final BookingService svc; private final BookingRepository repo;
  private boolean admin(Authentication a){ return a.getAuthorities().stream().anyMatch(x -> x.getAuthority().equals("ROLE_ADMIN")); }
  @GetMapping public List<Map<String,Object>> list(Authentication a){
    return (admin(a) ? repo.findAllByOrderByEventDateDesc() : repo.findByUserEmailOrderByEventDateDesc(a.getName())).stream().map(svc::view).toList();
  }
  @PostMapping @ResponseStatus(HttpStatus.CREATED) public Map<String,Object> create(@Valid @RequestBody BookingReq r, Authentication a){ return svc.view(svc.create(a.getName(), r)); }
  @PutMapping("/{id}/status") public Map<String,Object> status(@PathVariable Long id, @RequestParam Booking.Status status){ return svc.view(svc.setStatus(id, status)); }
  @DeleteMapping("/{id}") public Map<String,Object> cancel(@PathVariable Long id, Authentication a){ return svc.view(svc.cancel(id, a.getName(), admin(a))); }
}

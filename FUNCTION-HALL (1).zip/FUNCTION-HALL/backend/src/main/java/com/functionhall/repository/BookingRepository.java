package com.functionhall.repository;
import com.functionhall.entity.*; import org.springframework.data.jpa.repository.*; import java.time.*; import java.util.*;
public interface BookingRepository extends JpaRepository<Booking,Long> {
  List<Booking> findByUserEmailOrderByEventDateDesc(String email);
  List<Booking> findAllByOrderByEventDateDesc();
  @Query("select count(b) from Booking b where b.hall.id=:hallId and b.eventDate=:date and b.status in :active and b.startTime < :end and b.endTime > :start")
  long countOverlap(Long hallId, LocalDate date, LocalTime start, LocalTime end, Collection<Booking.Status> active);
}

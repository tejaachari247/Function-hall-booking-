package com.functionhall.config;
import com.functionhall.entity.*; import com.functionhall.repository.*; import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value; import org.springframework.boot.CommandLineRunner; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.stereotype.Component;
import java.math.BigDecimal;
@Component @RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {
  private final UserRepository users; private final HallRepository halls; private final PasswordEncoder enc;
  @Value("${app.admin.email}") String adminEmail; @Value("${app.admin.password}") String adminPass;
  public void run(String... args){
    if (!users.existsByEmail(adminEmail)) { User u = new User(); u.setFullName("Hall Administrator"); u.setEmail(adminEmail); u.setPhone("9000000000"); u.setPassword(enc.encode(adminPass)); u.setRole("ADMIN"); users.save(u); }
    if (!users.existsByEmail("customer@example.com")) { User u = new User(); u.setFullName("Demo Customer"); u.setEmail("customer@example.com"); u.setPhone("9111111111"); u.setPassword(enc.encode("Customer@123")); users.save(u); }
    if (halls.count() == 0) {
      halls.save(hall("Grand Hall", "Our flagship hall for weddings and receptions, with a raised stage and separate dining area.", 1000, 75000, "Air Conditioning,Stage,Dining Area,Parking,Generator,Decoration Area"));
      halls.save(hall("Premium Hall", "A refined hall for receptions, engagements and corporate gatherings.", 500, 45000, "Air Conditioning,Stage,Sound System,Parking,Generator"));
      halls.save(hall("Mini Hall", "An intimate space for birthdays, baby showers and seminars.", 200, 20000, "Air Conditioning,Wi-Fi,Sound System,Restrooms"));
    }
  }
  private Hall hall(String n, String d, int c, int p, String f){ Hall h = new Hall(); h.setName(n); h.setDescription(d); h.setCapacity(c); h.setPricePerDay(BigDecimal.valueOf(p)); h.setFacilities(f); return h; }
}

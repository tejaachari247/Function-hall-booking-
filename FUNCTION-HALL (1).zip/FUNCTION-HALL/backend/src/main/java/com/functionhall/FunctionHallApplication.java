package com.functionhall;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class FunctionHallApplication { public static void main(String[] a){ SpringApplication.run(FunctionHallApplication.class,a);} }

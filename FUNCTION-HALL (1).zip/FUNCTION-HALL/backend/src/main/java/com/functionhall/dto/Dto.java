package com.functionhall.dto;
import jakarta.validation.constraints.*; import java.time.*;
public final class Dto {
  private Dto(){}
  public record Register(@NotBlank String fullName, @Email @NotBlank String email, @Pattern(regexp="\\d{10}", message="Phone must be 10 digits") String phone, @Size(min=8, message="Password must be at least 8 characters") String password) {}
  public record Login(@NotBlank String email, @NotBlank String password) {}
  public record BookingReq(@NotNull Long hallId, @NotBlank String eventType, @NotNull LocalDate eventDate, @NotNull LocalTime startTime, @NotNull LocalTime endTime,
    @Min(1) int guests, @NotBlank String customerName, @Pattern(regexp="\\d{10}", message="Phone must be 10 digits") String phone, String requirements) {}
  public record HallReq(@NotBlank String name, String description, @Min(1) int capacity, @NotNull @Positive java.math.BigDecimal pricePerDay, String facilities, Boolean active) {}
}

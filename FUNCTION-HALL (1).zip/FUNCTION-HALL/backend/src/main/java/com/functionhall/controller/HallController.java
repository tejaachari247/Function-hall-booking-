package com.functionhall.controller;
import com.functionhall.dto.Dto.HallReq; import com.functionhall.entity.Hall; import com.functionhall.exception.ApiException; import com.functionhall.repository.HallRepository;
import com.functionhall.service.BookingService; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*;
import java.time.*; import java.util.*;
@RestController @RequestMapping("/api") @RequiredArgsConstructor
public class HallController {
  private final HallRepository halls; private final BookingService svc;
  @GetMapping("/halls") public List<Hall> list(@RequestParam(required=false) String q, @RequestParam(required=false) Integer minCapacity, @RequestParam(defaultValue="capacity") String sort){
    Comparator<Hall> c = switch (sort) { case "priceAsc" -> Comparator.comparing(Hall::getPricePerDay); case "priceDesc" -> Comparator.comparing(Hall::getPricePerDay).reversed(); default -> Comparator.comparingInt(Hall::getCapacity).reversed(); };
    return halls.findByActiveTrue().stream()
      .filter(h -> q == null || q.isBlank() || (h.getName()+" "+h.getFacilities()).toLowerCase().contains(q.toLowerCase()))
      .filter(h -> minCapacity == null || h.getCapacity() >= minCapacity).sorted(c).toList();
  }
  @GetMapping("/halls/{id}") public Hall one(@PathVariable Long id){ return halls.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Hall not found.")); }
  private Hall fill(Hall h, HallReq r){ h.setName(r.name()); h.setDescription(r.description()); h.setCapacity(r.capacity()); h.setPricePerDay(r.pricePerDay()); h.setFacilities(r.facilities()); if (r.active()!=null) h.setActive(r.active()); return halls.save(h); }
  @PostMapping("/halls") @ResponseStatus(HttpStatus.CREATED) public Hall add(@Valid @RequestBody HallReq r){ return fill(new Hall(), r); }
  @PutMapping("/halls/{id}") public Hall edit(@PathVariable Long id, @Valid @RequestBody HallReq r){ return fill(one(id), r); }
  @DeleteMapping("/halls/{id}") public Map<String,String> del(@PathVariable Long id){ Hall h = one(id); h.setActive(false); halls.save(h); return Map.of("message","Hall removed"); }
  @GetMapping("/availability")
  public Map<String,Object> availability(@RequestParam Long hallId, @RequestParam LocalDate date, @RequestParam LocalTime start, @RequestParam LocalTime end){
    svc.validateSlot(date, start, end);
    boolean ok = svc.isFree(hallId, date, start, end);
    return Map.of("available", ok, "message", ok ? "Hall available. You can continue with your booking." : "Sorry, this hall is already booked during the selected time.");
  }
}

package com.functionhall.security;
import com.functionhall.repository.UserRepository; import lombok.RequiredArgsConstructor; import org.springframework.context.annotation.*;
import org.springframework.http.*; import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity; import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain; import org.springframework.security.web.authentication.HttpStatusEntryPoint;
@Configuration @RequiredArgsConstructor
public class SecurityConfig {
  private final UserRepository users;
  @Bean PasswordEncoder encoder(){ return new BCryptPasswordEncoder(); }
  @Bean UserDetailsService uds(){
    return email -> users.findByEmail(email).map(u -> User.withUsername(u.getEmail()).password(u.getPassword()).roles(u.getRole()).disabled(!u.isEnabled()).build())
      .orElseThrow(() -> new UsernameNotFoundException("No such user"));
  }
  @Bean AuthenticationManager am(AuthenticationConfiguration c) throws Exception { return c.getAuthenticationManager(); }
  @Bean SecurityFilterChain chain(HttpSecurity http) throws Exception {
    http.csrf(c -> c.disable())
      .authorizeHttpRequests(a -> a
        .requestMatchers("/api/auth/register", "/api/auth/login", "/api/auth/me", "/api/auth/logout").permitAll()
        .requestMatchers(HttpMethod.GET, "/api/halls/**", "/api/availability").permitAll()
        .requestMatchers("/api/halls/**").hasRole("ADMIN")
        .requestMatchers(HttpMethod.PUT, "/api/bookings/*/status").hasRole("ADMIN")
        .requestMatchers("/api/**").authenticated()
        .anyRequest().permitAll())
      .exceptionHandling(e -> e.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)));
    return http.build();
  }
}

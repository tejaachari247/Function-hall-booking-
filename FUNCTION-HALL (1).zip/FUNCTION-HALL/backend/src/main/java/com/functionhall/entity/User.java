package com.functionhall.entity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="users") @Getter @Setter @NoArgsConstructor
public class User {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(nullable=false) private String fullName;
  @Column(nullable=false, unique=true) private String email;
  private String phone;
  @Column(nullable=false) private String password;
  @Column(nullable=false) private String role = "CUSTOMER";
  private boolean enabled = true;
}

package com.functionhall.exception;
import org.springframework.dao.DataIntegrityViolationException; import org.springframework.http.*;
import org.springframework.security.access.AccessDeniedException; import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException; import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestControllerAdvice
public class GlobalExceptionHandler {
  private ResponseEntity<Map<String,Object>> res(HttpStatus s, String m){ return ResponseEntity.status(s).body(Map.of("status", s.value(), "message", m)); }
  @ExceptionHandler(ApiException.class) ResponseEntity<?> api(ApiException e){ return res(e.getStatus(), e.getMessage()); }
  @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<?> invalid(MethodArgumentNotValidException e){
    return res(HttpStatus.BAD_REQUEST, e.getBindingResult().getFieldErrors().stream().map(f->f.getField()+": "+f.getDefaultMessage()).findFirst().orElse("Invalid input")); }
  @ExceptionHandler(AuthenticationException.class) ResponseEntity<?> auth(AuthenticationException e){ return res(HttpStatus.UNAUTHORIZED, "Invalid email or password, or account disabled."); }
  @ExceptionHandler(AccessDeniedException.class) ResponseEntity<?> denied(AccessDeniedException e){ return res(HttpStatus.FORBIDDEN, "You do not have permission to do that."); }
  @ExceptionHandler(DataIntegrityViolationException.class) ResponseEntity<?> dup(DataIntegrityViolationException e){ return res(HttpStatus.CONFLICT, "That record already exists or is in use."); }
  @ExceptionHandler(Exception.class) ResponseEntity<?> other(Exception e){ e.printStackTrace(); return res(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong. Please try again."); }
}

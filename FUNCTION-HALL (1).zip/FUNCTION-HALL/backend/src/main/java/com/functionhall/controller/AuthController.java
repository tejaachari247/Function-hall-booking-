package com.functionhall.controller;
import com.functionhall.dto.Dto.*; import com.functionhall.entity.User; import com.functionhall.exception.ApiException; import com.functionhall.repository.UserRepository;
import jakarta.servlet.http.*; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.http.*;
import org.springframework.security.authentication.*; import org.springframework.security.core.*; import org.springframework.security.core.context.*;
import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.security.web.context.HttpSessionSecurityContextRepository; import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api/auth") @RequiredArgsConstructor
public class AuthController {
  private final UserRepository users; private final PasswordEncoder enc; private final AuthenticationManager am;
  private Map<String,Object> info(User u){ return Map.of("fullName", u.getFullName(), "email", u.getEmail(), "role", u.getRole()); }
  @PostMapping("/register") @ResponseStatus(HttpStatus.CREATED)
  public Map<String,Object> register(@Valid @RequestBody Register r){
    if (users.existsByEmail(r.email())) throw new ApiException(HttpStatus.CONFLICT, "An account with this email already exists.");
    User u = new User(); u.setFullName(r.fullName()); u.setEmail(r.email()); u.setPhone(r.phone()); u.setPassword(enc.encode(r.password()));
    return info(users.save(u));
  }
  @PostMapping("/login")
  public Map<String,Object> login(@Valid @RequestBody Login r, HttpServletRequest req){
    Authentication a = am.authenticate(UsernamePasswordAuthenticationToken.unauthenticated(r.email(), r.password()));
    SecurityContext ctx = SecurityContextHolder.createEmptyContext(); ctx.setAuthentication(a); SecurityContextHolder.setContext(ctx);
    req.getSession(true).setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, ctx);
    return info(users.findByEmail(r.email()).orElseThrow());
  }
  @GetMapping("/me")
  public ResponseEntity<?> me(Authentication a){
    if (a == null || !a.isAuthenticated()) return ResponseEntity.status(401).build();
    return ResponseEntity.ok(info(users.findByEmail(a.getName()).orElseThrow()));
  }
  @PostMapping("/logout") public Map<String,String> logout(HttpServletRequest req){ HttpSession s = req.getSession(false); if (s != null) s.invalidate(); SecurityContextHolder.clearContext(); return Map.of("message","Logged out"); }
}

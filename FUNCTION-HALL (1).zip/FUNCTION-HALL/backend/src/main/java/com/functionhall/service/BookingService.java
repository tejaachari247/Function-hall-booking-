package com.functionhall.service;
import com.functionhall.dto.Dto.BookingReq; import com.functionhall.entity.*; import com.functionhall.entity.Booking.Status;
import com.functionhall.exception.ApiException; import com.functionhall.repository.*;
import lombok.RequiredArgsConstructor; import org.springframework.http.HttpStatus; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
import java.time.*; import java.util.*;
@Service @RequiredArgsConstructor
public class BookingService {
  private static final List<Status> ACTIVE = List.of(Status.PENDING, Status.CONFIRMED);
  private final BookingRepository bookings; private final HallRepository halls; private final UserRepository users;

  public void validateSlot(LocalDate d, LocalTime s, LocalTime e){
    if (d.isBefore(LocalDate.now())) throw new ApiException(HttpStatus.BAD_REQUEST, "Event date cannot be in the past.");
    if (!e.isAfter(s)) throw new ApiException(HttpStatus.BAD_REQUEST, "End time must be after start time.");
  }
  public boolean isFree(Long hallId, LocalDate d, LocalTime s, LocalTime e){ return bookings.countOverlap(hallId, d, s, e, ACTIVE) == 0; }

  @Transactional
  public Booking create(String email, BookingReq r){
    validateSlot(r.eventDate(), r.startTime(), r.endTime());
    Hall h = halls.lockById(r.hallId()).filter(Hall::isActive).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Hall not found."));
    if (r.guests() > h.getCapacity()) throw new ApiException(HttpStatus.BAD_REQUEST, h.getName()+" holds up to "+h.getCapacity()+" guests.");
    if (!isFree(h.getId(), r.eventDate(), r.startTime(), r.endTime()))
      throw new ApiException(HttpStatus.CONFLICT, "Unable to complete booking. The selected hall is already reserved. Please select another date or time.");
    Booking b = new Booking();
    b.setUser(users.findByEmail(email).orElseThrow()); b.setHall(h);
    b.setEmail(email); b.setCustomerName(r.customerName()); b.setPhone(r.phone()); b.setEventType(r.eventType());
    b.setEventDate(r.eventDate()); b.setStartTime(r.startTime()); b.setEndTime(r.endTime()); b.setGuests(r.guests()); b.setRequirements(r.requirements());
    b.setAmount(h.getPricePerDay()); b.setBookingCode(UUID.randomUUID().toString().substring(0, 12));
    b = bookings.save(b);
    b.setBookingCode("FH" + r.eventDate().getYear() + String.format("%04d", b.getId()));
    return b;
  }
  @Transactional
  public Booking setStatus(Long id, Status s){
    Booking b = bookings.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Booking not found."));
    b.setStatus(s); if (s == Status.COMPLETED) b.setPaymentStatus("PAID"); return b;
  }
  @Transactional
  public Booking cancel(Long id, String email, boolean admin){
    Booking b = bookings.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Booking not found."));
    if (!admin && !b.getUser().getEmail().equals(email)) throw new ApiException(HttpStatus.FORBIDDEN, "This is not your booking.");
    if (!ACTIVE.contains(b.getStatus())) throw new ApiException(HttpStatus.CONFLICT, "Only pending or confirmed bookings can be cancelled.");
    b.setStatus(Status.CANCELLED); return b;
  }
  public Map<String,Object> view(Booking b){
    Map<String,Object> m = new LinkedHashMap<>();
    m.put("id", b.getId()); m.put("bookingCode", b.getBookingCode()); m.put("hall", b.getHall().getName()); m.put("customerName", b.getCustomerName());
    m.put("eventType", b.getEventType()); m.put("eventDate", b.getEventDate()); m.put("startTime", b.getStartTime()); m.put("endTime", b.getEndTime());
    m.put("guests", b.getGuests()); m.put("amount", b.getAmount()); m.put("status", b.getStatus()); m.put("paymentStatus", b.getPaymentStatus()); return m;
  }
}

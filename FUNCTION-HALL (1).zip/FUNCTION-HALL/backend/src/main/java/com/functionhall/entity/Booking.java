package com.functionhall.entity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.*;
@Entity @Getter @Setter @NoArgsConstructor
@Table(name="bookings", indexes=@Index(name="idx_booking_slot", columnList="hall_id,eventDate,status"))
public class Booking {
  public enum Status { PENDING, CONFIRMED, REJECTED, CANCELLED, COMPLETED }
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @Column(unique=true, nullable=false) private String bookingCode;
  @ManyToOne(optional=false) @JoinColumn(name="user_id") private User user;
  @ManyToOne(optional=false) @JoinColumn(name="hall_id") private Hall hall;
  private String customerName, phone, email, eventType;
  private LocalDate eventDate; private LocalTime startTime, endTime;
  private int guests;
  @Column(length=1000) private String requirements;
  private BigDecimal amount;
  @Enumerated(EnumType.STRING) private Status status = Status.PENDING;
  private String paymentStatus = "PENDING";
  private LocalDateTime createdAt = LocalDateTime.now();
}
